abstract class AppAssets {
  static String splashGlow = "assets/images/Glow.png";
  static String splashLeft = "assets/images/left.png";
  static String splashRight = "assets/images/rieght.png";
  static String splashLogo = "assets/images/logo.png";
  static String splashRoute = "assets/images/Route.png";
  static String splashBg = "assets/images/splash.png";
  static String NavIcn1 = "assets/icons/navQuran.png";
  static String NavIcn2 = "assets/icons/icon2.png";
  static String NavIcn3 = "assets/icons/icon3.Png";
  static String NavIcn4 = "assets/icons/icon4.png";
  static String NavIcn5 = "assets/icons/icon5.png";
  static String homeBg = "assets/images/homeBg.png";
  static String Islami = "assets/images/Islami.png";
  static String Mos = "assets/images/Mosque-01.png";



}