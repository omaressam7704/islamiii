import 'dart:ui';

import 'package:flutter/material.dart';

class AppColors {
  static Color pri = Color(0xffE2BE7F);
  static Color sec = Color(0xff212121);
  static const Color selectedIconColor = Colors.white;
  static const Color unselectedIconColor = Colors.black;


}