package com.example.islami

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
